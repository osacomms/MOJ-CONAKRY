<?php

function synved_option_context_post($post_id)
{
	// XXX not implemented yet
}

?>
