<div class="w2dc-admin-wrap">
	<?php w2dc_renderMessages(); ?>
	